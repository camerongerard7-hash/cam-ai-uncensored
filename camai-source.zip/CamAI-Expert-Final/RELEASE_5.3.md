# Historical 5.3 release notes

Superseded by CamAI 5.4. See RELEASE_5.4.md.
