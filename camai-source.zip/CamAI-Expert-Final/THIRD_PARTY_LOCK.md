# Third-party source lock

CamAI does not bundle llama.cpp source in the source ZIP. CI fetches the upstream `master` ref at build time and records the exact resolved commit in `third_party/LLAMA_CPP_COMMIT` inside the CI workspace.

This is intentional for the source package, but it means reproducibility depends on the fetched upstream revision. For a release APK, pin `LLAMA_REF` to a reviewed llama.cpp commit before building.

The 4.3 native interface uses public llama.cpp APIs including `llama_model_chat_template` and `llama_chat_apply_template`. Current upstream headers expose these APIs, and the simple-chat example demonstrates applying the model's chat template to a multi-message conversation. citeturn0search3turn0search8
