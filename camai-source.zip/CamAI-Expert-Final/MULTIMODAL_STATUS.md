# Multimodal status

CamAI can select image files as attachments, but Build 2.2 does not perform image inference. This is intentional: llama.cpp has Android multimodal support, but model/projector compatibility and memory cost must be handled per model rather than pretending every GGUF can see images.
