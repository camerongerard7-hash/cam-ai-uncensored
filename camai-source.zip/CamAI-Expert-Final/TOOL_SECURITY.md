# Tool security boundary

Local tools are explicit commands. Network access is not granted implicitly. Future network tools must declare permission, input scope, output scope, and whether data leaves the device.
