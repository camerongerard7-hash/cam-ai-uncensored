# CamAI next 10 milestones: 4.4 -> 5.3

These ten milestones are advanced as one release train. Implementation status is recorded below. They are intentionally incremental so the phone remains the hard constraint.

| Milestone | Focus | Release gate |
|---|---|---|
| 4.4 | Runtime diagnostics | Engine/model/context state is observable without pretending to have device access |
| 4.5 | Memory guardrails | Model loading and generation fail early instead of gambling with low RAM |
| 4.6 | Conversation persistence hardening | Atomic local session writes, bounded history, recovery after interrupted writes |
| 4.7 | Privacy hardening | Explicit local-only state, wipe semantics, no background network requirement |
| 4.8 | Persona + epistemic core | System prompt layers are deterministic and inspectable |
| 4.9 | Tool security | Tools are allowlisted, local, explicit, and never silently networked |
| 5.0 | Model router | Auto/manual model selection is separated from inference implementation |
| 5.1 | Multimodal staging | Attachment pipeline is explicit; unsupported vision models never masquerade as vision |
| 5.2 | Agent foundation | Planning/state machine exists, but execution is deny-by-default |
| 5.3 | Release candidate | Reproducible CI APK build, checksums, source validation, and install handoff |

## Hard truth

The final APK cannot be truthfully called device-validated until it has been installed on a real Android device and has loaded a real GGUF model. The CI build proves compilation, not performance, thermal behavior, RAM stability, or generation quality on the target phone.

llama.cpp's current Android guidance recommends a reasonable initial context such as 4096 because excessive context can cause memory spikes, and it supports Android NDK cross-compilation for arm64-v8a. The release train therefore keeps 4096 as the conservative default. See the upstream Android documentation.

## Status at 5.3 RC1

- 4.4 Runtime diagnostics: **implemented** via `AppDiagnostics` and visible hardware diagnostics.
- 4.5 Memory guardrails: **implemented** with model-load RAM preflight and bounded GGUF import.
- 4.6 Persistence hardening: **partially implemented** through bounded role history and local persistence; full crash-safe encrypted storage remains a later hardening task.
- 4.7 Privacy hardening: **implemented for the base path** with no app `INTERNET` permission and explicit local-only tool behavior.
- 4.8 Persona + epistemic core: **implemented** through layered persona/mode instructions and explicit anti-fabrication rules.
- 4.9 Tool security: **implemented for current tools** because the base tool set is fixed, local, and network-disabled.
- 5.0 Model router: **implemented at the app abstraction level** with Auto/Manual local model selection.
- 5.1 Multimodal staging: **implemented as honest staging**. Images are recognized as attachments but are not falsely claimed to be understood.
- 5.2 Agent foundation: **architecture staged, execution deny-by-default**. No autonomous external actions are enabled.
- 5.3 Release candidate: **implemented** as a reproducible CI build path plus source validation. Device runtime is still a separate gate.
