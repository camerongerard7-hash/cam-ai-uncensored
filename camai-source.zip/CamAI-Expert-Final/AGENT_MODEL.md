# Agent model 3.0

CamAI now documents a future-safe agent boundary rather than pretending to have autonomous powers.

An agent action must have:
1. A named tool.
2. Explicit permission.
3. Bounded input.
4. Bounded output.
5. Cancellation.
6. Local/cloud disclosure.
7. A visible execution record.

The current build does not execute arbitrary shell commands, arbitrary JavaScript, or hidden network requests.
