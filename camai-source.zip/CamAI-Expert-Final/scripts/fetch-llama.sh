#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/third_party/llama.cpp"
REF="${LLAMA_REF:-436f6f89e1e581249900b37a5b8a12a36a6d0912}"
mkdir -p "$ROOT/third_party"
if [ -d "$DEST/.git" ]; then
  git -C "$DEST" fetch --depth 1 origin "$REF"
  git -C "$DEST" reset --hard FETCH_HEAD
else
  git clone --depth 1 https://github.com/ggml-org/llama.cpp "$DEST"
  git -C "$DEST" checkout --detach "$REF"
fi
COMMIT="$(git -C "$DEST" rev-parse HEAD)"
printf '%s\n' "$COMMIT" > "$ROOT/third_party/LLAMA_CPP_COMMIT"
printf 'llama.cpp ref: %s\ncommit: %s\n' "$REF" "$COMMIT"
