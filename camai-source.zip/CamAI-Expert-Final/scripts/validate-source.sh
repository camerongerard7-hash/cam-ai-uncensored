#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail=0
check() { if grep -Rqs --exclude-dir=.git -- "$2" "$1"; then echo "FOUND: $2"; else echo "MISSING: $2"; fail=1; fi; }
check "$ROOT/android/app/src/main/AndroidManifest.xml" 'android:label="CamAI"'
check "$ROOT/android/app/build.gradle.kts" 'versionName = "5.3.0"'
check "$ROOT/VERSION" '5.3.0'
check "$ROOT/android/app/src/main/java/ai/camai/app/NativeBridge.kt" 'roles: Array<String>'
check "$ROOT/android/app/src/main/cpp/native_engine.cpp" 'Java_ai_camai_app_NativeBridge_generateStream'
check "$ROOT/android/app/src/main/cpp/native_engine.cpp" 'llama_chat_apply_template'
check "$ROOT/android/app/src/main/java/ai/camai/app/MainActivity.kt" 'real roles instead of flattening'
check "$ROOT/android/app/src/main/AndroidManifest.xml" 'android:exported="true"'
if grep -q 'android.permission.INTERNET' "$ROOT/android/app/src/main/AndroidManifest.xml"; then echo 'FAIL: INTERNET permission present'; fail=1; else echo 'PASS: no INTERNET permission'; fi
if grep -q 'arm64-v8a' "$ROOT/android/app/build.gradle.kts"; then echo 'PASS: arm64-v8a'; else echo 'FAIL: arm64-v8a missing'; fail=1; fi
if grep -q 'GGML_OPENMP OFF' "$ROOT/android/app/src/main/cpp/CMakeLists.txt"; then echo 'PASS: OpenMP disabled'; else echo 'FAIL: OpenMP setting missing'; fail=1; fi
if grep -q 'GGML_CPU_KLEIDIAI' "$ROOT/android/app/src/main/cpp/CMakeLists.txt"; then echo 'FAIL: unverified KleidiAI toggle present'; fail=1; else echo 'PASS: no unverified KleidiAI toggle'; fi
APP_VERSION=$(sed -n 's/.*versionName = "\([^"]*\)".*/\1/p' "$ROOT/android/app/build.gradle.kts")
FILE_VERSION=$(tr -d '\r\n' < "$ROOT/VERSION")
if [ "$APP_VERSION" = "$FILE_VERSION" ]; then echo "PASS: version consistency $APP_VERSION"; else echo "FAIL: version mismatch"; fail=1; fi

exit "$fail"
